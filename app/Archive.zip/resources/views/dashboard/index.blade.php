@extends('layouts.auth')

@section('title','Dashboard')

@section('content')
<!-- main page wrapper start -->
<section class="main-page-wrapper marketplace-page-wrapper">
    <!-- page title -->
    <div class="page-title">
        <h1>Dashboard</h1>
    </div>
    <!-- page title --> 

</section>
<!-- main page wrapper end -->
@endsection